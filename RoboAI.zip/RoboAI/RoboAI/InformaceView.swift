//
//  InformaceView.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import Foundation
import SwiftUI

struct InformaceView: View {
var body: some View {
VStack(alignment: .leading, spacing: 20) {
Text("RoboAI Asistent")
.font(.largeTitle)
Text("Verze: 1.0")
.font(.title2)
Text("Vývojář: Lukáš Helebrandt")
.foregroundColor(.secondary)
Text("Tato aplikace vám pomůže komunikovat s robotem a získat informace z internetu pomocí umělé inteligence.")
.foregroundColor(.secondary)
Text("V aplikaci je použita technologie OpenAI GPT-3, která dokáže generovat texty, odpovědi na otázky a mnoho dalšího.")
.foregroundColor(.secondary)
Text("Pro použití aplikace je nutné mít připojení k internetu.")
.foregroundColor(.secondary)
Spacer()
}
.padding()
.navigationTitle("Info")
}
}
