//
//  ContentView.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import SwiftUI
import CoreData

struct ContentView: View {

    var body: some View {
        TabView {
            SeznamChatuView()
                .tabItem {
                    Image(systemName: "message.fill")
                    Text("Chaty")
                }
            ProfilView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profil")
                }
            InformaceView()
                .tabItem {
                    Image(systemName: "info.circle.fill")
                    Text("Info")
                }
            DonateView()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text("Donate")
                }

        }
    }
}

    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
