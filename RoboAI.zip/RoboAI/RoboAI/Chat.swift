import Foundation

struct Chat: Identifiable {
    let id = UUID()
    let nazev: String
    var zpravy: [Zprava]
    let datumVytvoreni: Date
    
    var posledniZprava: String {
        return zpravy.last?.text ?? ""
    }
    
    var neprecteno: Bool {
        return zpravy.contains { !$0.precteno }
    }
}

struct Zprava: Identifiable {
    let id = UUID()
    let text: String
    let casOdeslani: Date
    var precteno: Bool
}
