import SwiftUI

struct SeznamChatuView: View {
    @State private var seznamChatu = [
        Chat(nazev: "Chat 1", zpravy: [], datumVytvoreni: Date()),
    ]

    @State private var zobrazitVytvoritChat = false

    var body: some View {
        NavigationView {
            List {
                ForEach(seznamChatu) { chat in
                    NavigationLink(
                        destination: DetailChatuView(chat: chat),
                        label: {
                            HStack {
                                                            Image(systemName: "circle.fill")
                                                                .foregroundColor(.blue)
                                                            Text(chat.nazev)
                                                                .font(.headline)
                                                                .multilineTextAlignment(.center)
                                                                .padding(.vertical, 8)
                                                        }
                            SeznamChatuRowView(chat: chat)
                        })
                }
                .onDelete(perform: odstranitChat)
                .onMove(perform: presunoutChat)
            }
            .navigationTitle("Seznam chatů")
            .navigationBarItems(
                leading: Button(action: {
                    zobrazitVytvoritChat.toggle()
                }) {
                    Image(systemName: "plus")
                },
                trailing: EditButton()
            )
            .sheet(isPresented: $zobrazitVytvoritChat) {
                VytvoritChatView(seznamChatu: $seznamChatu)
            }
             .overlay(seznamChatu.isEmpty ? Text("Momentálně není otevřený žádný chat.") : nil, alignment: .center)
         
        }
    }

    func odstranitChat(at offsets: IndexSet) {
        seznamChatu.remove(atOffsets: offsets)
    }

    func presunoutChat(from source: IndexSet, to destination: Int) {
        seznamChatu.move(fromOffsets: source, toOffset: destination)
    }
}
