import SwiftUI

struct VytvoritChatView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var seznamChatu: [Chat]
    @State private var nazevChatu = ""
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Název chatu", text: $nazevChatu)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: {
                    seznamChatu.append(Chat(nazev: nazevChatu, zpravy: [], datumVytvoreni: Date()))
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    Text("Vytvořit chat")
                })
                .disabled(nazevChatu.isEmpty)
                .padding()
                
                Spacer()
            }
            .navigationTitle("Vytvořit nový chat")
        }
    }
}
