//
//  DetailChatuView.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import Foundation
import SwiftUI
import CoreData

var chatHistories: [String: [Message]] = [:]
let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .short
    return formatter
}()

struct DetailChatuView: View {
    let chat: Chat
    @State private var message = ""
    @State private var chatLog: [Message] = []
    @State private var scrollToBottom = false
    @State private var isAnimating = false // přidáme nový stav pro animaci teček
    let openAIManager = OpenAIManager()
    
    @Environment(\.managedObjectContext) private var viewContext

    func sendMessage(messageType: Message.MessageType) {
        let userMessage = Message(content: message, sender: .user, messageType: messageType)
        chatLog.append(userMessage)
        chatHistories[chat.nazev, default: []].append(userMessage) // uložení zprávy do historie chatu
        scrollToBottom = true

        openAIManager.getAIResponse(prompt: message) { result in
            switch result {
            case .success(let response):
                let aiMessage = Message(content: response, sender: .ai, messageType: messageType)
                chatLog.append(aiMessage)
                chatHistories[chat.nazev, default: []].append(aiMessage) // uložení zprávy do historie chatu
                scrollToBottom = true
                isAnimating = true // spustíme animaci
            case .failure(let error):
                print(error.localizedDescription)
            }
        }

        message = "" // vynulujeme obsah textového pole
    }


    var body: some View {
        VStack {
            ScrollViewReader { scrollView in
                ScrollView {
                    VStack(alignment: .trailing, spacing: 8) {
                        ForEach(chatLog.indices, id: \.self) { index in
                            MessageView(message: chatLog[index])
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .onAppear {
                        if chatLog.count > 0 {
                            scrollView.scrollTo(chatLog.count - 1, anchor: .bottom)
                        }
                    }
                    .onChange(of: scrollToBottom) { value in
                        if value {
                            scrollView.scrollTo(chatLog.count - 1, anchor: .bottom)
                            scrollToBottom = false
                        }
                    }
                }
            }

            HStack {
                           TextField("Napište zprávu", text: $message, onCommit: { sendMessage(messageType: .text) })
                               .padding(8)
                               .background(Color.gray.opacity(0.2))
                               .cornerRadius(10)
                       }
            .padding(16)
        }
        .navigationBarTitle(chat.nazev)
        .onAppear {
            chatLog.append(Message(content: "Začněte psát zprávy pro robota", sender: .ai, messageType: .text))
        }
    }
}

struct MessageView: View {
    let message: Message
    
    var body: some View {
            HStack {
                if message.sender == .ai {
                    Image(systemName: "person.crop.circle.fill")
                        .foregroundColor(Color.green)
                        .font(.system(size: 20))
                        .padding(.trailing, 8) // přidáme vnitřní odsazení (padding) zprava pro ikonku
                    VStack(alignment: .leading, spacing: 4) {
                        Text(message.content)
                            .padding(10)
                            .background(message.sender == .ai ? Color.green : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                            .frame(maxWidth: .infinity, alignment: .leading) // zpráva bude neomezeně dlouhá
                        Text(message.timestamp, formatter: dateFormatter) // zobrazení datumu
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                } else {
                    VStack(alignment: .trailing, spacing: 4) { // nastavíme zarovnání na pravou stranu
                        Text(message.content)
                            .padding(10)
                            .background(message.sender == .ai ? Color.green : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                            .frame(maxWidth: .infinity, alignment: .trailing) // zpráva bude neomezeně dlouhá
                        Text(message.timestamp, formatter: dateFormatter) // zobrazení datumu
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                    Image(systemName: "person.crop.circle.fill") // přidáme ikonku a nastavíme odsazení
                        .foregroundColor(Color.blue)
                        .font(.system(size: 20))
                        .padding(.leading, 8) // přidáme vnitřní odsazení (padding) zleva pro ikonku
                }
            }
        }
    }




struct Message: Identifiable {
    enum Sender {
        case user
        case ai
    }

    enum MessageType {
        case text
        case image
    }

    let id = UUID()
    let content: String
    let sender: Sender
    let messageType: MessageType
    let timestamp = Date() // přidáme novou property pro timestamp

    var timestampString: String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .short
        return formatter.string(from: timestamp)
    }
}
