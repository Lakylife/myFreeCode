//
//  ChatHistory.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import Foundation
struct ChatHistory: Codable {
    let id: UUID
    var messages: [Message]

    init(id: UUID, messages: [Message] = []) {
        self.id = id
        self.messages = messages
    }

    mutating func addMessage(_ message: Message) {
        messages.append(message)
    }

    mutating func clear() {
        messages.removeAll()
    }
}

