import SwiftUI

struct LoadingView: View {
    @State private var isLoading = false
    
    var body: some View {
        VStack {
            Text("Načítání...")
                .font(.headline)
                .padding()
            if isLoading {
                ProgressView()
            }
        }
        .onAppear {
            withAnimation {
                isLoading = true
            }
        }
    }
}
