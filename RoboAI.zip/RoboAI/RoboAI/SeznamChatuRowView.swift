import SwiftUI

struct SeznamChatuRowView: View {
    let chat: Chat
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(chat.posledniZprava)
                    .foregroundColor(chat.neprecteno ? .red : .secondary)
            }
            Spacer()
            Text(formattedDate(date: chat.datumVytvoreni))
                .foregroundColor(.secondary)
        }
    }
    
    func formattedDate(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
