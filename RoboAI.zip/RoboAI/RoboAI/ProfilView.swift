//
//  ProfilView.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import Foundation
import SwiftUI

struct ProfilView: View {
    var body: some View {
        VStack {
            Image("avatar")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                .padding(.top, 30)
            Text("Jan Novák")
                .font(.title)
                .padding(.top, 20)
            Text("jan.novak@email.cz")
                .foregroundColor(.secondary)
                .padding(.top, 5)
            Spacer()
        }
        .padding()
        .navigationTitle("Profil")
    }
}
