import Foundation
import Alamofire
struct OpenAIResponse: Decodable {
    let choices: [OpenAIChoice]
}

struct OpenAIChoice: Decodable {
    let text: String
    let index: Int
    let logprobs: OpenAILogprobs
}

struct OpenAILogprobs: Decodable {
    // definice logprobs atributů
}
class OpenAIManager {
    private let apiURL = "https://api.openai.com/v1"
    private let apiKey = "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"
    private let model = "text-davinci-003"

    func getAIResponse(prompt: String, completion: @escaping (Result<String, Error>) -> Void) {
        let headers: HTTPHeaders = [
            "Content-Type": "application/json",
            "Authorization": "Bearer \(apiKey)"
        ]
        
        let parameters: Parameters = [
            "model": model,
            "prompt": prompt,
            "temperature": 0.7,
            "max_tokens": 150,
            "top_p": 1,
            "frequency_penalty": 0,
            "presence_penalty": 0
        ]

        AF.request("\(apiURL)/completions", method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .validate()
            .responseDecodable(of: OpenAIResponse.self) { response in
                switch response.result {
                case .success(let openaiResponse):
                    if let text = openaiResponse.choices.first?.text {
                        completion(.success(text))
                    } else {
                        completion(.failure(NSError(domain: "OpenAI Error", code: 0, userInfo: [NSLocalizedDescriptionKey: "Could not parse OpenAI response"])))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
