import SwiftUI
import CoreImage.CIFilterBuiltins

struct DonateView: View {
    @State private var btcAdresa = "1MTsLPCXhUmVqht1yTmu12WHtSsfqapAZp"
    @State private var zobrazeniKodu = false

    var body: some View {
        VStack {
            if zobrazeniKodu {
                Image(uiImage: generovatQRKod(text: btcAdresa))
                    .resizable()
                    .scaledToFit()
                    .padding()
                
                Text(btcAdresa)
                    .font(.headline)
                    .padding()
                
                Button(action: {
                    UIPasteboard.general.string = btcAdresa
                }, label: {
                    Image(systemName: "doc.on.doc")
                })
                .padding()
            } else {
                Text("Podpořte nás")
                    .font(.title)
                    .padding()

                Text("Rádi bychom dál vylepšovali naši aplikaci a přidávali nové funkce. Pokud si přejete podpořit náš projekt, můžete nás finančně přispět.")
                    .multilineTextAlignment(.center)
                    .padding()

                Button(action: {
                    zobrazeniKodu = true
                }, label: {
                    Text("Přispět")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 20)
                        .background(Color.green)
                        .cornerRadius(10)
                })
                .padding()
            }
            Spacer()
        }
    }

    func generovatQRKod(text: String) -> UIImage {
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        let data = Data(text.utf8)
        filter.setValue(data, forKey: "inputMessage")
        let transform = CGAffineTransform(scaleX: 10, y: 10)
        if let output = filter.outputImage?.transformed(by: transform),
           let cgImage = context.createCGImage(output, from: output.extent) {
            return UIImage(cgImage: cgImage)
        }
        return UIImage()
    }
}
