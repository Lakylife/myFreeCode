//
//  chatHistories.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import Foundation

class ChatHistory: ObservableObject {
    @Published var histories: [Chat]

    init(histories: [Chat] = []) {
        self.histories = histories
    }

    func add(history: Chat) {
        self.histories.append(history)
    }

    func delete(at index: Int) {
        self.histories.remove(at: index)
    }

    func clear() {
        self.histories = []
    }
}

let chatHistories = ChatHistory()
