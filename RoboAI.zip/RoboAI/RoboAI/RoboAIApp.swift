//
//  RoboAIApp.swift
//  RoboAI
//
//  Created by Lukas Helebrandt on 29.03.2023.
//

import SwiftUI

@main
struct RoboAIApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
